package Dominio;

import java.util.ArrayList;

import Persistencia.CamionesDao;
import Persistencia.TurismosDao;

public class Camiones extends Vehiculos {
private double c_carga;
private CamionesDao camionesdao;

public Camiones(String matricula, String marca, String modelo, String color, Double cuota, double c_carga) {
	super(matricula, marca, modelo, color, cuota);
	this.c_carga = c_carga;
	camionesdao= new CamionesDao();
}


public Camiones() {
	camionesdao= new CamionesDao();
}

public double getC_carga() {
	 return c_carga;
}

public void setC_carga(double c_carga) {
	this.c_carga = c_carga;
}



@Override
public String toString() {
	return  "Camiones:  matricula=" + matricula + ", marca=" + marca + ", modelo=" + modelo 	+ ", color=" + color + ", cuota=" + cuota + " ,c_carga=" + c_carga ;
		
}


public void insertar() throws ClassNotFoundException {
	camionesdao.insertar(this);
}


public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException {
	return camionesdao.leerTodos();

}

public Vehiculos leervehiculo(String matricula) throws ClassNotFoundException {
	return camionesdao.leer(matricula);

}

public void actualizar(String matricula) throws ClassNotFoundException {
	camionesdao.actualizar(this, matricula);

}


public void eliminar() throws ClassNotFoundException {
	camionesdao.eliminar(this);
}

public void eliminarTodo() throws ClassNotFoundException {
	camionesdao.eliminarTodo();

}





}
