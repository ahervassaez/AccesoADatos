package Dominio;

import java.util.ArrayList;

import Persistencia.VehiculosDao;

public abstract class Vehiculos {
	protected  String matricula;
	protected  String marca;
	protected  String modelo;
	protected  String color;
	protected  Double cuota;
	protected VehiculosDao vehiculodao;
	
	public Vehiculos(String matricula, String marca, String modelo, String color, Double cuota) {
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
		this.cuota = cuota;
	}

public Vehiculos() {
	
}
	public  String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public  String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public  String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public  String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public  Double getCuota() {
		return cuota;
	}


	public void setCuota(Double cuota) {
		this.cuota = cuota;
	}


	@Override
	public String toString() {
		return "Vehiculos [matricula=" + matricula + ", marca=" + marca + ", modelo=" + modelo + ", color=" + color
				+ ", cuota=" + cuota + "]";
	}



	abstract public void insertar() throws ClassNotFoundException ;
	abstract public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException ;
	abstract public Vehiculos leervehiculo(String matricula) throws ClassNotFoundException;
	abstract public void actualizar(String matricula) throws ClassNotFoundException ;
	abstract public void eliminar() throws ClassNotFoundException;

abstract public void eliminarTodo() throws ClassNotFoundException;

}

