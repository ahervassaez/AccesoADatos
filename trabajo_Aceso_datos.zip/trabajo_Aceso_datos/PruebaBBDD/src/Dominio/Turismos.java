package Dominio;

import java.util.ArrayList;


import Persistencia.TurismosDao;

public class Turismos extends Vehiculos {

private int n_puertas;
private int idExtra;
private  ArrayList<Extras> extras = new ArrayList<Extras>();
private  TurismosDao turismosdao;




public Turismos(String matricula, String marca, String modelo, String color, Double cuota, int n_puertas, int idExtra
		) {
	super(matricula, marca, modelo, color, cuota);
	this.n_puertas = n_puertas;
	this.idExtra = idExtra;
	turismosdao =  new TurismosDao();
}


public Turismos() {
	turismosdao= new TurismosDao();
}


public int getN_puertas() {
	return n_puertas;
}


public void setN_puertas(int n_puertas) {
	this.n_puertas = n_puertas;
}




//modificar bien el toString



public ArrayList<Extras> getExtras() {
	return extras;
}


public void setExtras(ArrayList<Extras> extras) {
	this.extras = extras;
}


@Override
public void insertar() throws ClassNotFoundException {
    turismosdao.insertar(this);

}


@Override
public String toString() {
	return "Turismos:  matricula="+ matricula + ", marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", cuota=" + cuota + " ,n�mero de puertas: " +n_puertas + ", extra=" + idExtra; 
			
			
	
	
}


@Override
public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException {
    return turismosdao.leerTodos();

}


@Override
public Vehiculos leervehiculo(String matricula) throws ClassNotFoundException {
    // TODO Auto-generated method stub
    return turismosdao.leer(matricula);

}


@Override
public void actualizar(String matricula) throws ClassNotFoundException {
    turismosdao.actualizar(this, matricula);
}


@Override
public void eliminar() throws ClassNotFoundException {
    turismosdao.eliminar(this);

}


@Override
public void eliminarTodo() throws ClassNotFoundException {
    turismosdao.eliminarTodo();

}
}