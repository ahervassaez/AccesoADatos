package Dominio;

import java.util.ArrayList;


import Persistencia.ExtrasDao;

public class Extras {

	private int id;
	private String descripcion;
	private ExtrasDao extrasdao;

	
	public Extras(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
		this.extrasdao=new ExtrasDao();
	}
	

	public Extras() {
		this.extrasdao=new ExtrasDao();

	}

	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Override
	public String toString() {
		return "id: " + id + ", Descripci�n:=" + descripcion ;
	}



	public Extras leerExtra(int id) throws ClassNotFoundException {
		return extrasdao.leer(id);
	}
	
	
	public void insertar() throws ClassNotFoundException {
	        extrasdao.insertar(this);
	    }
	
	    public ArrayList<Extras>  leerTodos() throws ClassNotFoundException {
	        return extrasdao.leerTodos();

	    }
	    public Extras leer(int id) throws ClassNotFoundException {
	    return extrasdao.leer(id);

	   }

	    public void actualizar(int id) throws ClassNotFoundException {
	        extrasdao.actualizar(this, id);

	    }

	    public void eliminar() throws ClassNotFoundException {
	        extrasdao.eliminar(this);
	    }

	    public void eliminarTodo() throws ClassNotFoundException {
	        extrasdao.eliminarTodo();

	    }

	
}

