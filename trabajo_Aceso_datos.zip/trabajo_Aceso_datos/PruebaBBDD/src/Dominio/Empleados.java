package Dominio;

import java.util.ArrayList;

import Persistencia.EmpleadosDao;

public class Empleados {
private String usuario;
private String contrase�a;
private EmpleadosDao empleadosDao;



public Empleados(String usuario, String contrase�a, EmpleadosDao empleadosDao) {
	super();
	this.usuario = usuario;
	this.contrase�a = contrase�a;
	this.empleadosDao = empleadosDao;
}

public Empleados () {
	this.empleadosDao = new EmpleadosDao();
}
public String getUsuario() {
	return usuario;
}
public void setUsuario(String usuario) {
	this.usuario = usuario;
}
public String getContrase�a() {
	return contrase�a;
}
public void setContrase�a(String contrase�a) {
	this.contrase�a = contrase�a;
}
@Override
public String toString() {
	return "Empleados [usuario=" + usuario + ", contrase�a=" + contrase�a + "]";
}

public Empleados leer(String usuario, String contrase�a ) throws ClassNotFoundException {
	return empleadosDao.leer(usuario, contrase�a);
}


}

