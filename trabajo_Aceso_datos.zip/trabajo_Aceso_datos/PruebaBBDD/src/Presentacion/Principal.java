package Presentacion;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import Dominio.Camiones;
import Dominio.Empleados;
import Dominio.Extras;

import Dominio.Turismos;
import Dominio.Vehiculos;
import Persistencia.Conexion;

class numnegexception extends Exception { // nueva excepcion

}

class maxpuertasException extends Exception {// nueva excepcion

}

public class Principal {
	public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {

		login();

	}

	public static void login() throws ClassNotFoundException, IOException {
		boolean seguir = true;
		do {
			try {
				System.out.println("Inserte Usuario: ");
				Scanner sc = new Scanner(System.in);
				String usuario = sc.nextLine();

				System.out.println("Introduzca Contrase�a:");
				String contrase�a = sc.nextLine();

				Empleados leerEmpleado = new Empleados();
				leerEmpleado = leerEmpleado.leer(usuario, contrase�a);

				System.out.printf("Bienvenido %s", leerEmpleado.getUsuario());

				if (leerEmpleado != null) {
					seguir = true;

					menPrincipal(); // llama al men� principal si existe el empleado
				}
			} catch (NullPointerException e) {
				System.err.println("Usuario o contrase�a err�neos");
				seguir = false;
			}
		} while (!seguir);
	}//fin de login

	public static void menPrincipal() throws ClassNotFoundException, IOException {

		Scanner sc = new Scanner(System.in);
		int opcion = 0;
		// Men� principal
		do {
			try {
				System.out.println();
				System.out.println("Men�");
				System.out.println("1. Mostrar todos los vehiculos");
				System.out.println("2. Buscar un vehiculo");
				System.out.println("3. Insertar un vehiculo");
				System.out.println("4. Modificar un vehiculo");
				System.out.println("5. Eliminar un vehiculo");
				System.out.println("6. Eliminar todos los vehiculos");
				System.out.println("7. Mostrar todos los extras");
				System.out.println("8. Buscar un extra");
				System.out.println("9. Insertar un extra");
				System.out.println("10. Modificar un extra");
				System.out.println("11. Eliminar un extra");
				System.out.println("12. Eliminar todas los extras");
				System.out.println("13. Log out");
				opcion = sc.nextInt();

				switch (opcion) {
				case 1:
					mostrarTodos();
					break;
				case 2:
					buscarVehiculo();
					break;
				case 3:
					InsertarVehiculo();
					break;
				case 4:
					modificarVehiculos();
					break;
				case 5:
					eliminarVehiculo();
					break;
				case 6:
					eliminarTodasVehiculos();
					break;
				case 7:
					mostrarTodosExtras();
					break;
				case 8:
					buscarExtra();
					break;
				case 9:
					insertarExtra();
					break;
				case 10:
					modificarExtra();
					break;
				case 11:
					eliminarExtra();
					break;
				case 12:
					eliminarTodosLosExtras();
					break;
				case 13:
					System.out.println("Hasta pronto");
					login();
					break;
				default:
					System.out.println("Introduce un n�mero de 1 a 13");
				}

			} catch (InputMismatchException e) {
				System.err.println("Introduce un n�mero");
				sc.nextLine();
			}
		} while (opcion != 13);
	}//fin de menu principal

	public static void eliminarTodosLosExtras() throws ClassNotFoundException, IOException {
		
		int opcion = 0;
		Scanner sc = new Scanner(System.in);
		do {
			try {
				System.out.println("�Quieres continuar? 1.si | 2. no"); //evitar borrar por accidente
			
				opcion = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Introduzce solo n�meros");
				sc.nextLine();
			}
		} while (opcion != 1 && opcion != 2);
		
		if (opcion ==1) {
		Extras eliminarTodosExtras = new Extras();
		eliminarTodosExtras.eliminarTodo();
		
		}
		if (opcion == 2) {
			System.out.println("operaci�n abortada");
			menPrincipal();
			}
		

	}//fin de eliminartodosloaextras

	public static void eliminarExtra() throws ClassNotFoundException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Indica el Id");
		int id = sc.nextInt();
		Extras BExtra = new Extras();
		BExtra = BExtra.leer(id);

		if (BExtra != null) {
			BExtra.eliminar();

		} else {
			System.out.printf("No existe el extra con el Id %d\n", id);
		}
	}//fin de eliminar extra

	public static void modificarExtra() throws ClassNotFoundException {
		Scanner sc = new Scanner(System.in);

		Extras modExtra = new Extras();

		System.out.println("Indica el Id");
		int id = sc.nextInt();
		modExtra = modExtra.leerExtra(id);

		if (modExtra != null) {
			System.out.println("�Qu� deseas modificar?");
			System.out.println("1. Id");
			System.out.println("2. Descripci�n");
			int opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				boolean repetido = false;
				do {
					repetido = false;
					System.out.println("Introduce el nuevo Id");
					int Id = sc.nextInt();
					Extras existeExtra = new Extras();
					existeExtra = existeExtra.leerExtra(Id);

					if (existeExtra != null) {
						if (existeExtra.getId() == Id) {
							System.out.println("Id repetido");
							repetido = true;
						}
					} else {

						modExtra.setId(Id);
					}
				} while (repetido);
				break;

			case 2:
				System.out.println("Introduce la descripcion");
				sc.nextLine();
				String descripcion = sc.nextLine();
				modExtra.setDescripcion(descripcion);
				break;

			}
			modExtra.actualizar(id);
		} else {
			System.out.printf("No existe el extra con el Id %d\n", id);

		}
	}//fin de modificar extra

	public static void insertarExtra() throws ClassNotFoundException {
		Scanner sc = new Scanner(System.in);

		boolean seguir = false;
		int id = 0;
		do {
			seguir = false;
			System.out.println("Introduzca el id");
			id = sc.nextInt();
			Extras existeExtra = new Extras();
			existeExtra = existeExtra.leerExtra(id);

			if (existeExtra != null) {

				if (existeExtra.getId() == id) {
					System.out.println("Id repetido");
					seguir = true;
				}
			}

		} while (seguir);

		System.out.println("Introduzca la descripcion");
		sc.nextLine();
		String descripcion = sc.nextLine();

		Extras newExtra = new Extras(id, descripcion);
		newExtra.insertar();
	}// fin de insertar extra

	public static void buscarExtra() throws ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Indica el id");
		int id = sc.nextInt();
		Extras leerExtra = new Extras();
		leerExtra = leerExtra.leerExtra(id);

		if (leerExtra != null) {
			System.out.println(leerExtra.toString());
		} else {
			System.out.printf("No existe el extra con el id %d\n", id);
		}
	}//fin de buscar extra

	public static void mostrarTodosExtras() throws ClassNotFoundException {

		boolean sinExtras = true;
		Extras buscarExtra = new Extras();
		ArrayList<Extras> Extra = buscarExtra.leerTodos();
		for (int i = 0; i < Extra.size(); i++) {
			System.out.println(Extra.get(i).toString());
			sinExtras = false;
		}

		if (sinExtras) {
			System.out.println("No existen Extras");

		}
	}//fin de mostrar todos extras

	public static void eliminarTodasVehiculos() throws ClassNotFoundException, IOException {
		int opcion = 0;
		Scanner sc = new Scanner(System.in);
		do {
			try {
				System.out.println("�Quieres continuar? 1.si | 2. no");
			
				opcion = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Introduzce solo n�meros");
				sc.nextLine();
			}
		} while (opcion != 1 && opcion != 2);
		
		if (opcion ==1) {
		
		Vehiculos elominartodo = new Camiones();
		elominartodo.eliminarTodo();
		elominartodo = new Turismos();
		elominartodo.eliminarTodo();
		
		}
		
		if (opcion == 2) {
			System.out.println("operaci�n abortada");
		menPrincipal();
		}
	}//fin de eliminar todos vehiculos

	public static void modificarVehiculos() throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		Vehiculos modTurismo = new Turismos();
		Vehiculos modCamiones = new Camiones();

		System.out.println("Indica la matricula");
		String Matricula = sc.next();
		modTurismo = modTurismo.leervehiculo(Matricula);
		modCamiones = modCamiones.leervehiculo(Matricula);

		if (modTurismo != null || modCamiones != null) {
			System.out.println("�Qu� deseas modificar?");
			System.out.println("1. Matricula");
			System.out.println("2. Marca");
			System.out.println("3. Modelo");
			System.out.println("4. Color");
			System.out.println("5. Cuota");
			if (modTurismo != null) {
				System.out.println("6. Extra");
				System.out.println("7.N�mero de puertas");

			} else if (modCamiones != null) {
				System.out.println("6. Carga");
			}
			int opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				boolean repetido = false;
				do {
					repetido = false;
					System.out.println("Introduce la nueva Matricula");
					String matN = sc.next();

					// no modifica la matricula
					Vehiculos existeTurismo = new Turismos();
					existeTurismo = existeTurismo.leervehiculo(matN);
					Vehiculos existeCamion = new Camiones();
					existeCamion = existeCamion.leervehiculo(matN);

					if (existeTurismo != null) {
						if (existeTurismo.getMatricula().equals(matN)) {
							System.out.println("Matricula repetido de turismo");
							repetido = true;
						}
					} else if (existeCamion != null) {
						if (existeCamion.getMatricula().equals(matN)) {
							System.out.println("Matricula repetido de camion");
							repetido = true;
						}
					} else {

						if (modTurismo != null) {
							modTurismo.setMatricula(matN);
						}
						if (modCamiones != null) {
							modCamiones.setMatricula(matN);
						}
					}
				} while (repetido);
				break;
			case 2:
				System.out.println("Introduce la neuva marca");
				sc.nextLine();
				String Marca = sc.nextLine();
				if (modTurismo != null) {
					modTurismo.setMarca(Marca);
				}
				if (modCamiones != null) {
					modCamiones.setMarca(Marca);
				}
				break;
			case 3:
				System.out.println("Introduce el nuevo modelo");
				sc.nextLine();
				String modelo = sc.nextLine();
				if (modTurismo != null) {
					modTurismo.setModelo(modelo);
				}
				if (modCamiones != null) {
					modCamiones.setModelo(modelo);
				}
				break;
			case 4:
				System.out.println("Introduce el nuevo Color");
				sc.nextLine();
				String Color = sc.nextLine();
				if (modTurismo != null) {
					modTurismo.setColor(Color);
				}
				if (modCamiones != null) {
					modCamiones.setColor(Color);
				}
				break;
			case 5:
				boolean seguir = false;
				do {
					seguir = false;
					try {
						System.out.println("Introduce la nueva cuota");
						double cuota = sc.nextDouble();

						if (cuota <= 0) { // excepcion en caso de que la cuota sea igual o mayor a 0
							throw new numnegexception();
						}
						if (modTurismo != null) {
							modTurismo.setCuota(cuota);
						}
						if (modCamiones != null) {
							modCamiones.setCuota(cuota);
						}

					} catch (InputMismatchException e) {
						System.err.println("Introduzce solo n�meros");
						sc.nextLine();
						seguir = true;
					} catch (numnegexception e) {
						System.err.println("No se permiten n�meros inferiores o iguales a 0");
						sc.nextLine();
						seguir = true;
					}
				} while (seguir);
				break;
			case 6:
				if (modTurismo != null) {
					seguir = false;
					do {
						seguir = false;
						try {

							mostrarTodosExtras();
							System.out.println("Introduce el nueva Extra");
							int Extra = sc.nextInt();
							Extras modExtra = new Extras();
							modExtra = modExtra.leerExtra(Extra);
							if (modExtra == null) {
								seguir = true;
								System.out.println("La Extra no existe");

							} else {
								((Turismos) modTurismo).setExtra(modExtra);
							}

						} catch (InputMismatchException e) {
							System.err.println("Introduzce solo n�meros");
							sc.nextLine();
							seguir = true;
						}
					} while (seguir);
				} else if (modCamiones != null) {
					seguir = false;
					do {
						seguir = false;
						try {
							System.out.println("Introduce la nueva  carga");
							double carga = sc.nextDouble();
							((Camiones) modCamiones).setC_carga(carga);

						} catch (InputMismatchException e) {
							System.err.println("Introduzce solo n�meros");
							sc.nextLine();
							seguir = true;
						}
					} while (seguir);
				}
				break;

			case 7:

				if (modTurismo != null) {
					seguir = false;
					do {
						seguir = false;
						try {
							System.out.println("Introduce n�mero de puertas");
							int puertas = sc.nextInt();
							if (puertas > 8) {// limitar puertas
								throw new maxpuertasException();

							}
							((Turismos) modTurismo).setN_puertas(puertas);

						}

						catch (InputMismatchException e) {
							System.err.println("Introduzce solo n�meros");
							sc.nextLine();
							seguir = true;
						}

						catch (maxpuertasException e) {
							System.err.println("No existe un veh�culo con tantas puertas");
							sc.nextLine();
							seguir = true;
						}
					} while (seguir);
				}
				break;

			}
			if (modTurismo != null) {
				modTurismo.actualizar(Matricula);

			} else if (modCamiones != null) {
				modCamiones.actualizar(Matricula);

			}

		} else {
			System.out.printf("No existe el vehiculo con la matricula %s\n", Matricula);

		}

	}//fin de modificar vehiculos

	public static void eliminarVehiculo() throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Indica la matricula");
		String Matricula = sc.next();
		Vehiculos Turismo = new Turismos();
		Turismo = Turismo.leervehiculo(Matricula);
		Vehiculos Camiones2 = new Camiones();
		Camiones2 = Camiones2.leervehiculo(Matricula);
		if (Turismo != null) {
			Turismo.eliminar();
		} else if (Camiones2 != null) {
			Camiones2.eliminar();
		} else {
			System.out.printf("No existe el vehiculo con esta matricula: %s\n", Matricula);
		}
	}// fin de eliminar vehiculos

	public static void InsertarVehiculo() throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		boolean seguir = false;
		String Matricula = "";
		Extras newExtra = new Extras();
		do {
			seguir = false;
			System.out.println("Introduzca la matricula");
			Matricula = sc.next();
			Vehiculos ExisteTurismo = new Turismos();
			ExisteTurismo = ExisteTurismo.leervehiculo(Matricula);
			Vehiculos ExisteCamion = new Camiones();
			ExisteCamion = ExisteCamion.leervehiculo(Matricula);
			if (ExisteTurismo != null) {

				if (ExisteTurismo.getMatricula().equals(Matricula)) {
					System.out.println("Matricula repetida");
					seguir = true;
				}
			}

			else if (ExisteCamion != null) {

				if (ExisteCamion.getMatricula().equals(Matricula)) {
					System.out.println("Matricula repetida");
					seguir = true;
				}
			}
		} while (seguir);
		System.out.println("Introduzca nueva Marca");
		sc.nextLine();
		String Marca = sc.nextLine();
		System.out.println("Introduzca el modelo");
		String Modelo = sc.nextLine();
		System.out.println("Introduzca el Color");
		String Color = sc.nextLine();
		double Cuota = 0;
		do {
			seguir = false;
			try {
				System.out.println("Introduzca la cuota");
				Cuota = sc.nextDouble();

				if (Cuota <= 0) {
					throw new numnegexception();
				}

			} catch (InputMismatchException e) {
				System.err.println("Introduzce solo n�meros");
				seguir = true;
				sc.nextLine();

			} catch (numnegexception e) {
				System.err.println("No se permiten numeros inferiores o iguales a 0");
				seguir = true;
				sc.nextLine();
			}

		} while (seguir);
		int opcion = 0;
		do {
			try {
				System.out.println("�Es Turismo o Camion?\n1. Turismo\n2. Camion");
				opcion = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Introduzce solo n�meros");
				sc.nextLine();
			}
		} while (opcion != 1 && opcion != 2);
		int Extra = 0;
		int NPuertas = 0;
		if (opcion == 1) {

			do {
				seguir = false;
				try {

					System.out.println("Introduzca numero de puertas");
					NPuertas = sc.nextInt();

					if (NPuertas > 8) { // s� existen coches con 8 puertas, si se ponen mas el programa no deja
						throw new maxpuertasException();
					}
					mostrarTodosExtras();
					System.out.println("Introduzca el extra");
					Extra = sc.nextInt();
					newExtra = new Extras();
					newExtra = newExtra.leerExtra(Extra);
					if (newExtra == null) {
						seguir = true;
						System.out.println("El extra no existe");

					}
				} catch (InputMismatchException e) {
					System.err.println("Introduzce solo n�meros");
					seguir = true;
					sc.nextLine();

				} catch (maxpuertasException e) {
					System.err.println("No existe un veh�culo con tantas puertas");
					seguir = true;
					sc.nextLine();

				}

			} while (seguir);

			Vehiculos newVehiculos = new Turismos(Matricula, Marca, Modelo, Color, Cuota, NPuertas, newExtra);
			newVehiculos.insertar();

		}

		double carga = 0;
		if (opcion == 2) {

			do {
				seguir = false;
				try {
					System.out.println("Introduzca la capacidad de carga");
					carga = sc.nextDouble();
				} catch (InputMismatchException e) {
					System.err.println("Introduzce solo n�meros");
					seguir = true;
					sc.nextLine();
				}
			} while (seguir);
			Vehiculos newVehiculos = new Camiones(Matricula, Marca, Modelo, Color, Cuota, carga);
			newVehiculos.insertar();
		}

	}// fin de insertar vehiculos

	public static void buscarVehiculo() throws ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Indica la matricula");
		String matricula = sc.next();
		Vehiculos leerTurismo = new Turismos();
		leerTurismo = leerTurismo.leervehiculo(matricula);
		Vehiculos leerCamion = new Camiones();
		leerCamion = leerCamion.leervehiculo(matricula);
		if (leerTurismo != null) {
			System.out.println(leerTurismo.toString());
		} else if (leerCamion != null) {
			System.out.println(leerCamion.toString());
		} else {
			System.out.printf("No existe el vehiculo con la matricula %s\n", matricula);
		}

	}// fin de buscar vehiculos

	public static void mostrarTodos() throws ClassNotFoundException {
		boolean sinvehiculo = true;
		Vehiculos buscarVehiculo = new Turismos();
		ArrayList<Vehiculos> vehiculos = buscarVehiculo.leerTodos();
		for (int i = 0; i < vehiculos.size(); i++) {
			System.out.println(vehiculos.get(i).toString());
			sinvehiculo = false;
		}
		buscarVehiculo = new Camiones();
		vehiculos = buscarVehiculo.leerTodos();
		for (int i = 0; i < vehiculos.size(); i++) {
			System.out.println(vehiculos.get(i).toString());
			sinvehiculo = false;
		}
		if (sinvehiculo) {
			System.out.println("No se ha encontrado ningun veh�culo");

		}
	}// fin de mostrar todos 
}// fin de clase principal
