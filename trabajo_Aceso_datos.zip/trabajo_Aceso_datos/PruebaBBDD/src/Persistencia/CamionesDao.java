package Persistencia;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Dominio.Camiones;
import Dominio.Vehiculos;




public class CamionesDao {

	public CamionesDao() {
		
	}
	
	public boolean insertar(Camiones camiones) throws ClassNotFoundException {
		boolean registrar = false;
		
		Statement stm= null;
		Connection con=null;
		
		String sql="INSERT INTO Vehiculos  values ('"+camiones.getMatricula()+"','"+camiones.getMarca()+"','"+camiones.getModelo()+"','"+camiones.getColor()+ "'," + camiones.getCuota()+")";                        
		String sql2="INSERT INTO Camiones values ('"+camiones.getMatricula()+"',"+((Camiones)camiones).getC_carga()+")";

		try {			
			con=Conexion.conectar();
			stm= con.createStatement();
			stm.execute(sql);
			stm.execute(sql2);
			registrar=true;
			stm.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao, m�todo insertar");
			e.printStackTrace();
		}
		
		
		return registrar;
	}
	
	public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException {
		Connection co = null;
		Statement stm = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM Camiones ORDER BY matricula";

		ArrayList<Vehiculos> listaVehiculos = new ArrayList<Vehiculos>();

		try {
			co = Conexion.conectar();
			stm = co.createStatement();
			rs = stm.executeQuery(sql);
			while (rs.next()) {
				listaVehiculos.add(new Camiones(rs.getString(1), "", "", "",0.0,rs.getDouble(2))); // ahora si
			}
			stm.close();
			rs.close();
			co.close();
			for (int i = 0; i < listaVehiculos.size(); i++) {
				co = Conexion.conectar();
				stm = co.createStatement();
				sql = "SELECT * FROM Vehiculos WHERE matricula='" + listaVehiculos.get(i).getMatricula() + "'";
				rs = stm.executeQuery(sql);
				rs.next();
				listaVehiculos.get(i).setMarca(rs.getString(2));
				listaVehiculos.get(i).setModelo(rs.getString(3));
				listaVehiculos.get(i).setColor(rs.getString(4));
				listaVehiculos.get(i).setCuota(rs.getDouble(5));

				stm.close();
				rs.close();
				co.close();
			}
		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao, m�todo leerTodo");
			e.printStackTrace();
		}

		return listaVehiculos;
	}
	
	public Vehiculos leer(String matricula) throws ClassNotFoundException {
		Connection co = null;
		Statement stm = null;
		ResultSet rs = null;

		Vehiculos leerVehiculos= null;
		String sql = "SELECT * FROM Camiones WHERE matricula='" + matricula + "'";
		try {
			co = Conexion.conectar();
			stm = co.createStatement();
			rs = stm.executeQuery(sql);
			while (rs.next()) {
				leerVehiculos = new Camiones(rs.getString(1), "", "", "",0.0, rs.getDouble(2)); //ahora si
			}
			stm.close();
			rs.close();
			co.close();
			if (leerVehiculos != null) {
				co = Conexion.conectar();
				stm = co.createStatement();
				sql = "SELECT * FROM Vehiculos WHERE matricula='" + leerVehiculos.getMatricula() + "'";
				rs = stm.executeQuery(sql);
				rs.next();
				leerVehiculos.setMarca(rs.getString(2));
				leerVehiculos.setModelo(rs.getString(3));
				leerVehiculos.setColor(rs.getString(4));
				leerVehiculos.setCuota(rs.getDouble(5));
			}

		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao Error:  m�todo eliminar");
			e.printStackTrace();
		}
		return leerVehiculos;
	}
	
	public boolean actualizar(Vehiculos camiones, String matricula) throws ClassNotFoundException {
		Connection connect= null;
		Statement stm= null;
		
		boolean actualizar=false;
		if(camiones.getMatricula().equals(matricula)) {			
		String sql="UPDATE Vehiculos SET matricula='"+camiones.getMatricula()+"', marca='"+camiones.getMarca()+"', modelo='"+camiones.getModelo()+"', color='"+camiones.getColor()+"',cuota="+camiones.getCuota()+" WHERE matricula='"+camiones.getMatricula()+"'";
		String sql2="UPDATE Camiones SET matricula='"+camiones.getMatricula()+"', c_carga="+((Camiones)camiones).getC_carga()+" WHERE matricula='"+camiones.getMatricula()+"'";
		try {
			connect=Conexion.conectar();
			stm=connect.createStatement();
			stm.execute(sql);
			stm.execute(sql2);
			actualizar=true;
			stm.close();
			connect.close();
		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao Error: m�todo actualizar");
			e.printStackTrace();
		}		
		}else {
		String sql="INSERT INTO Vehiculos  values ('"+camiones.getMatricula()+"','"+camiones.getMarca()+"','"+camiones.getModelo()+"','"+camiones.getColor()+ "'," + camiones.getCuota()+")"; 
		String sql2="INSERT INTO Camiones values ('"+camiones.getMatricula()+"',"+((Camiones)camiones).getC_carga()+")";
		String sql3="DELETE FROM Camiones WHERE matricula='"+matricula+"'";
		String sql4="DELETE FROM Vehiculos WHERE matricula='"+matricula+"'";
		
		try {
			connect=Conexion.conectar();
			stm=connect.createStatement();
			stm.execute(sql);
			stm.execute(sql2);
			stm.execute(sql3);
			stm.execute(sql4);

			actualizar=true;
			stm.close();
			connect.close();
		} catch (SQLException e) {
			System.out.println("Error: m�todo actualizar");
			e.printStackTrace();
		}	
		}
			
		
		return actualizar;
	}


	public boolean eliminar(Vehiculos camiones) throws ClassNotFoundException {
		Connection connect= null;
		Statement stm= null;
		
		boolean eliminar=false;
		
		String sql="DELETE FROM Camiones WHERE matricula='"+camiones.getMatricula()+"'";
		String sql2="DELETE FROM Vehiculos WHERE matricula='"+camiones.getMatricula()+"'";

		try {
			connect=Conexion.conectar();
			stm=connect.createStatement();
			stm.execute(sql);
			stm.execute(sql2);
			eliminar=true;
		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao  m�todo eliminar");
			e.printStackTrace();
		}				
			
		return eliminar;
	}

	public boolean eliminarTodo() throws ClassNotFoundException {
		Connection connect= null;
		Statement stm= null;
		
		boolean eliminar=false;
				
		String sql="DELETE FROM Camiones";
		
		try {
			connect=Conexion.conectar();
			stm=connect.createStatement();
			stm.execute(sql);
			eliminar=true;
		} catch (SQLException e) {
			System.out.println("Error: clase: camionesDao  m�todo eliminarTodo");
			e.printStackTrace();
		}		
		return eliminar;		
	}

	
	
}
