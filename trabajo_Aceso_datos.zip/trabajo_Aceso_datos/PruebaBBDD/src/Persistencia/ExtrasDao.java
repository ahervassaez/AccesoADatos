package Persistencia;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Dominio.Extras;

public class ExtrasDao {



public ExtrasDao () {
	
}

public boolean insertar(Extras extras) throws ClassNotFoundException {
	boolean registrar = false;
	
	Statement stm= null;
	Connection con=null;
	
	String sql="INSERT INTO Extras values ("+extras.getId()+", '"+extras.getDescripcion()+"')";
	
	try {			
		con=Conexion.conectar();
		stm= con.createStatement();
		stm.execute(sql);
		registrar=true;
		stm.close();
		con.close();
	} catch (SQLException e) {
		System.out.println("Error: Clase extrasDao, m�todo insertar");
		e.printStackTrace();
	}
	return registrar;
	
}

public ArrayList<Extras> leerTodos() throws ClassNotFoundException {
	Connection co =null;
	Statement stm= null;
	ResultSet rs=null;
	
	String sql="SELECT * FROM Extras ORDER BY id";
	
	ArrayList<Extras> listaExta= new ArrayList<Extras>();
	
	try {			
		co= Conexion.conectar();
		stm=co.createStatement();
		rs=stm.executeQuery(sql);
		while (rs.next()) {
			listaExta.add(new Extras(rs.getInt(1),rs.getString(2)));
		}
		stm.close();
		rs.close();
		co.close();
	} catch (SQLException e) {
		System.out.println("Error: Clase extrasDao, m�todo leertodos");
		e.printStackTrace();
	}
	
	return listaExta;
}

public Extras leer(int id) throws ClassNotFoundException {
	Connection co =null;
	Statement stm= null;
	ResultSet rs=null;
	Extras leerExtra = null;
	String sql="SELECT * FROM Extras WHERE id="+id + " ";
	try {
		co= Conexion.conectar();
		stm=co.createStatement();
		rs=stm.executeQuery(sql);
		while (rs.next()) {
			leerExtra = new Extras(rs.getInt(1),rs.getString(2));
		}
		stm.close();
		rs.close();
		co.close();
	} catch (SQLException e) {
		System.out.println("Error:  m�todo leer clase ExtrasDao");
		e.printStackTrace();
	}		
	return leerExtra;
}


public boolean actualizar(Extras extra, int id) throws ClassNotFoundException {
	Connection connect= null;
	Statement stm= null;
	
	boolean actualizar=false;
	
	String sql="UPDATE Extras SET id="+extra.getId()+", descripcion='"+extra.getDescripcion()+"' WHERE id="+id+"";
	try {
		connect=Conexion.conectar();
		stm=connect.createStatement();
		stm.execute(sql);
		actualizar=true;
	} catch (SQLException e) {
		System.out.println("Error: m�todo actualizar clase becasdao");
		e.printStackTrace();
	}
	
		
	return actualizar;
}



public boolean eliminar(Extras extra) throws ClassNotFoundException {
	Connection connect= null;
	Statement stm= null;
	boolean actualizar=false;
	boolean eliminar=false;
	String sql="UPDATE Turismos SET Extra=1 WHERE Extra="+extra.getId()+"";
	try {
		connect=Conexion.conectar();
		stm=connect.createStatement();
		stm.execute(sql);
		actualizar=true;
		stm.close();
		connect.close();
	} catch (SQLException e) {
		System.out.println("Error: m�todo en actualizar clase extrasdao");
		e.printStackTrace();
	}	
	sql="DELETE FROM Extras WHERE id="+extra.getId()+"";
	try {
		connect=Conexion.conectar();
		stm=connect.createStatement();
		stm.execute(sql);
		eliminar=true;
	} catch (SQLException e) {
		System.out.println("Error:  m�todo eliminar clase extrasdao");
		e.printStackTrace();
	}		
	return eliminar;
}

public boolean eliminarTodo() throws ClassNotFoundException {
	Connection connect= null;
	Statement stm= null;
	
	boolean eliminar=false;
	boolean actualizar=false;
	String sql="UPDATE Turismos set extra = 1";
	try {
		connect=Conexion.conectar();
		stm=connect.createStatement();
		stm.execute(sql);
		actualizar=true;
		stm.close();
		connect.close();
	} catch (SQLException e) {
		System.out.println("Error: m�todo actualizar  clase extrasdao");
		e.printStackTrace();
	}	
	sql="DELETE FROM Extras WHERE id<>1";
	try {
		connect=Conexion.conectar();
		stm=connect.createStatement();
		stm.execute(sql);
		eliminar=true;
	} catch (SQLException e) {
		System.out.println("Error:  m�todo eliminar clase extrasdao");
		e.printStackTrace();
	}		
	return eliminar;		
}
}