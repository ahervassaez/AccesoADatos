package Persistencia;

import java.util.ArrayList;

import Dominio.Vehiculos;

abstract  public class VehiculosDao {
	
public VehiculosDao() {
	
}
abstract public boolean insertar(Vehiculos Vehiculos) throws ClassNotFoundException ;
abstract public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException;
abstract public Vehiculos leer(String matricula) throws ClassNotFoundException ;
abstract public boolean actualizar(Vehiculos Vehiculos, String matricula) throws ClassNotFoundException;
abstract public boolean eliminar(Vehiculos Vehiculos) throws ClassNotFoundException ;
abstract public boolean eliminarTodo() throws ClassNotFoundException;
}
