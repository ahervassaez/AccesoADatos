package Persistencia;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Dominio.Camiones;
import Dominio.Empleados;
import Dominio.Extras;
import Dominio.Vehiculos;

public class EmpleadosDao {

	
	public EmpleadosDao() {
		
	}
	
	public Empleados leer(String usuario, String contrase�a ) throws ClassNotFoundException {// se pasan esto dos parametros
		Connection co =null;
		Statement stm= null;
		ResultSet rs=null;
		Empleados leerUsuario = null;
		String sql="SELECT * FROM Empleados WHERE usuario='"+usuario + "' and contarse�a='" + contrase�a + "'";
		try {
			co= Conexion.conectar();
			stm=co.createStatement();
			rs=stm.executeQuery(sql);
			while (rs.next()) {
				leerUsuario = new Empleados (rs.getString(1),rs.getString(2), null);
			}
			stm.close();
			rs.close();
			co.close();
		} catch (SQLException e) {
			System.out.println("Error:  m�todo leer clase ExtrasDao");
			e.printStackTrace();
		}		
		return leerUsuario;
	}
	
}

