
package Persistencia;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Dominio.Extras;
import Dominio.Turismos;
import Dominio.Vehiculos;

public class TurismosDao extends VehiculosDao{
	
	public TurismosDao() {
		
	}
	


	public   boolean insertar(Vehiculos turismos) throws ClassNotFoundException {
		boolean registrar = false;

		Statement stm = null;
		Connection con = null;

		String sql = "INSERT INTO Vehiculos values ('" + turismos.getMatricula() + "','" + turismos.getMarca() + "','"
				+ turismos.getModelo() + "','" + turismos.getColor() +"'," +  turismos.getCuota()   + ")";
		String sql2 = "INSERT INTO Turismos values ('" + turismos.getMatricula() + "'," +  ((Turismos)turismos).getN_puertas() + ")";

		try {
			con = Conexion.conectar();
			stm = con.createStatement();
			stm.execute(sql);
			stm.execute(sql2);
			registrar = true;
			stm.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("Error: Clase TurismosDao, m�todo insertar");
			e.printStackTrace();
		}

		
		return registrar;
	}

	@Override
	public ArrayList<Vehiculos> leerTodos() throws ClassNotFoundException {
		Connection co = null;
		Statement stm = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM Turismos ORDER BY matricula";

		ArrayList<Vehiculos> listaVehiculos = new ArrayList<Vehiculos>();
		ArrayList<Extras> listaExtras = new ArrayList<Extras>(); //cambio
		Extras extras = new Extras();
		ArrayList<Integer> auxExtra=new ArrayList<Integer>();
		try {
			co = Conexion.conectar();
			stm = co.createStatement();
			rs = stm.executeQuery(sql);
			while (rs.next()) {
				auxExtra.add(rs.getInt(3));	
			
				listaVehiculos.add(new Turismos(rs.getString(1), "", "", "", null ,rs.getInt(2), extras.getId() )); //cambio
			}
			
			
			stm.close();
			rs.close();
			co.close();
			//cambiar mas tarde despues de hacer el metodo leerTurismosExtras() en extras
			for (int i=0;i<auxExtra.size();i++) {
				extras= extras.leerExtra(auxExtra.get(i));
				((Turismos)listaVehiculos.get(i)).setExtra(extras);
				//a�adir el numero de puertas
			

			}

			for (int i = 0; i < listaVehiculos.size(); i++) {
				co = Conexion.conectar();
				stm = co.createStatement();
				sql = "SELECT * FROM Vehiculos WHERE matricula='" + listaVehiculos.get(i).getMatricula() + "'";
				rs = stm.executeQuery(sql);
				rs.next();
				listaVehiculos.get(i).setMarca(rs.getString(2));
				listaVehiculos.get(i).setModelo(rs.getString(3));
				listaVehiculos.get(i).setColor(rs.getString(4));
				listaVehiculos.get(i).setCuota(rs.getDouble(5));

				stm.close();
				rs.close();
				co.close();
			}
		} catch (SQLException e) {
			System.out.println("Error: Clase turismosdao, m�todo obtener");
			e.printStackTrace();
		}

		return listaVehiculos;
	}
	
	/////cambiar a turismosextras
	
	// curso = extra
	//turismos = estudiantes
	
	/*
	 *public ArrayList<Curso> leerCursoEstudiante(Estudiante estudiante) throws ClassNotFoundException {
        Connection co =null;
        Statement stm= null;
        ResultSet rs=null;

        String sql="SELECT * FROM Matricular4 WHERE estudiante='"+estudiante.getDNI()+"'ORDER BY estudiante";

        ArrayList<Curso> listaCursos= new ArrayList<Curso>();

        try {
            co= Conexion.conectar();
            stm=co.createStatement();
            rs=stm.executeQuery(sql);

            while (rs.next()) {
                Curso curso = new Curso();
                listaCursos.add(curso.leerCurso(rs.getInt(2),true));
            }

            stm.close();
            rs.close();
            co.close();
        } catch (SQLException e) {
            System.out.println("Error: Clase CursoDaoImple, m�todo obtener");
            e.printStackTrace();
        }

        return listaCursos;

	 * */
	 
	

	@Override
	public Vehiculos leer(String matricula) throws ClassNotFoundException {
		Connection co = null;
		Statement stm = null;
		ResultSet rs = null;

		Vehiculos leerVehiculos = null;
		String sql = "SELECT * FROM Turismos WHERE matricula='" + matricula + "'";
		Extras extras = new Extras();
		int auxExtras=0;
	    boolean encontrado=false;
		try {
			co = Conexion.conectar();
			stm = co.createStatement();
			rs = stm.executeQuery(sql);
			while (rs.next()) {
			auxExtras=rs.getInt(3);
			encontrado=true;
				leerVehiculos = new Turismos(rs.getString(1), "", "", null, null, rs.getInt(2), extras);
			}
			stm.close();
			rs.close();
			co.close();
			if(encontrado) {
			extras=extras.leerExtra(auxExtras);
			((Turismos)leerVehiculos).setExtra(extras);
			}
			if (leerVehiculos != null) {
				co = Conexion.conectar();
				stm = co.createStatement();
				sql = "SELECT * FROM Vehiculos WHERE matricula='" + leerVehiculos.getMatricula() + "'";
				rs = stm.executeQuery(sql);
				rs.next();
				leerVehiculos.setMarca(rs.getString(2));
				leerVehiculos.setModelo(rs.getString(3));
				leerVehiculos.setColor(rs.getString(4));
				leerVehiculos.setCuota(rs.getDouble(5));
			}
		} catch (SQLException e) {
			System.out.println("Error:  m�todo leer clase turismosdao");
			e.printStackTrace();
		}
		return leerVehiculos;
	}
//faltan estos metodos por hacer
	@Override
	public boolean actualizar(Vehiculos Turismos, String matricula) throws ClassNotFoundException {
		Connection connect = null;
        Statement stm = null;

        boolean actualizar = false;

        if(Turismos.getMatricula().equals(matricula)) {
        String sql="UPDATE Vehiculos SET matricula='"+Turismos.getMatricula()+"', marca='"+Turismos.getMarca()+"', modelo='"+Turismos.getModelo()+"', color='"+Turismos.getColor()+"',cuota="+Turismos.getCuota()+" WHERE matricula='"+Turismos.getMatricula()+"'";
        String sql2="UPDATE Turismos SET matricula='"+Turismos.getMatricula()+"',  n_puertas="+    ((Turismos) Turismos).getN_puertas()     +", extra="+((Turismos) Turismos).getExtra().getId()+" WHERE matricula='"+Turismos.getMatricula()+"'";
        try {
            connect=Conexion.conectar();
            stm=connect.createStatement();
            stm.execute(sql);
            stm.execute(sql2);
            actualizar=true;
            stm.close();
            connect.close();
        } catch (SQLException e) {
            System.out.println("Error: m�todo actualizar");
            e.printStackTrace();
        }
        }else {
        String sql="INSERT INTO Vehiculos values ('"+Turismos.getMatricula()+"','"+Turismos.getMarca()+"','"+Turismos.getModelo()+"','"+Turismos.getColor()+"',"+Turismos.getCuota()+")";
        String sql2="INSERT INTO Turismos values ('"+Turismos.getMatricula()+"',"+ ((Turismos)Turismos).getN_puertas() + "," +((Turismos) Turismos).getExtra().getId()+")";
        String sql3="DELETE FROM Turismos WHERE matricula='"+matricula+"'";
        String sql4="DELETE FROM Vehiculos WHERE matricula='"+matricula+"'";
        try {
            connect=Conexion.conectar();
            stm=connect.createStatement();
            stm.execute(sql);
            stm.execute(sql2);
            stm.execute(sql3);
            stm.execute(sql4);

            actualizar=true;
            stm.close();
            connect.close();
        } catch (SQLException e) {
            System.out.println("Error: m�todo actualizar");
            e.printStackTrace();
        }
        }
        return actualizar;
    }

	@Override
	public boolean eliminar(Vehiculos Turismos) throws ClassNotFoundException {
		Connection connect = null;
        Statement stm = null;

        boolean eliminar = false;

        String sql = "DELETE FROM Turismos WHERE matricula='" + Turismos.getMatricula() + "'";
        String sql2 = "DELETE FROM Vehiculos WHERE matricula='" + Turismos.getMatricula() + "'";

        try {
            connect = Conexion.conectar();
            stm = connect.createStatement();
            stm.execute(sql);
            stm.execute(sql2);
            eliminar = true;
        } catch (SQLException e) {
            System.out.println("Error:  m�todo eliminar");
            e.printStackTrace();
        }

        return eliminar;
    }
    
	

	@Override
	public boolean eliminarTodo() throws ClassNotFoundException {
		Connection connect = null;
        Statement stm = null;

        boolean eliminar = false;

        String sql = "DELETE FROM Turismos";
        try {
            connect = Conexion.conectar();
            stm = connect.createStatement();
            stm.execute(sql);
            sql = "DELETE FROM Vehiculos";
            connect = Conexion.conectar();
            stm = connect.createStatement();
            stm.execute(sql);
            eliminar = true;
        } catch (SQLException e) {
            System.out.println("Error:  m�todo eliminar");
            e.printStackTrace();
        }
        return eliminar;

    }

	
}
